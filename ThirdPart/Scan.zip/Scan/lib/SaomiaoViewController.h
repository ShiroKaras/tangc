//
//  SaomiaoViewController.h
//  DouYU
//
//  Created by SiYugui on 16/4/25.
//  Copyright © 2016年 Alesary. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SaomiaoViewController : UIViewController

@end
